package eeit.OldProject.daniel.repository.post.topic;

import org.springframework.data.jpa.repository.JpaRepository;

import eeit.OldProject.daniel.entity.post.topic.PostTopicClassifier;

public interface PostTopicClassifierRepository extends JpaRepository<PostTopicClassifier, Long> {
}
