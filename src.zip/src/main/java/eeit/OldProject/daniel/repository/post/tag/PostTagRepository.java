package eeit.OldProject.daniel.repository.post.tag;

import org.springframework.data.jpa.repository.JpaRepository;

import eeit.OldProject.daniel.entity.post.tag.PostTag;

public interface PostTagRepository extends JpaRepository<PostTag, Long> {
}