package eeit.OldProject.daniel.repository.post.category;

import org.springframework.data.jpa.repository.JpaRepository;

import eeit.OldProject.daniel.entity.post.category.PostCategory;

public interface PostCategoryRepository extends JpaRepository<PostCategory, Long> {}
