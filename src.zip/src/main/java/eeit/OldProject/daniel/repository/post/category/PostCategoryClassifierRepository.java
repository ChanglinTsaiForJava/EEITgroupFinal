package eeit.OldProject.daniel.repository.post.category;

import org.springframework.data.jpa.repository.JpaRepository;

import eeit.OldProject.daniel.entity.post.category.PostCategoryClassifier;

public interface PostCategoryClassifierRepository extends JpaRepository<PostCategoryClassifier, Long> {}
