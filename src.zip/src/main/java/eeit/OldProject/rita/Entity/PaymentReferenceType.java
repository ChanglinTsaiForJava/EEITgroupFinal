package eeit.OldProject.rita.Entity;

public enum PaymentReferenceType {
    Appointment,
    Order
}
