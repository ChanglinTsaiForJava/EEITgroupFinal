package eeit.OldProject.rita.Entity;

public enum PaymentStatus {
    Pending,
    Paid,
    Failed
}
