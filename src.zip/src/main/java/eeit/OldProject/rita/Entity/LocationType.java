package eeit.OldProject.rita.Entity;

public enum LocationType {
    醫院,
    居家
}
