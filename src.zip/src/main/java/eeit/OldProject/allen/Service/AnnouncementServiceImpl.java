package eeit.OldProject.allen.Service;

public class AnnouncementServiceImpl implements AnnouncementService {

}
