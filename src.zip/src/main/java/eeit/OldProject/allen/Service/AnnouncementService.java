package eeit.OldProject.allen.Service;

public interface AnnouncementService {
	
}
