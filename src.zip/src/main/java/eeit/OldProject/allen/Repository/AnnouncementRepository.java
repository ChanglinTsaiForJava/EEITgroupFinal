package eeit.OldProject.allen.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import eeit.OldProject.allen.Entity.Announcement;

public interface AnnouncementRepository extends JpaRepository<Announcement, Integer> {

}
