package eeit.OldProject.allen.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import eeit.OldProject.allen.Entity.AnnouncementCategory;

public interface AnnouncementCategoryRepository extends JpaRepository<AnnouncementCategory, Integer> {

}
