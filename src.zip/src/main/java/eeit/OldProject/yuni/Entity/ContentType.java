package eeit.OldProject.yuni.Entity;

public enum ContentType {
    video,
    article
}
