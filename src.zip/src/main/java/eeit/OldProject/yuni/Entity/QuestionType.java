package eeit.OldProject.yuni.Entity;

public enum QuestionType {
    single,
    multiple
}
