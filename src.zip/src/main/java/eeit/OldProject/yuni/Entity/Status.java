package eeit.OldProject.yuni.Entity;

public enum Status {
    not_started,
    in_progress,
    completed
}
