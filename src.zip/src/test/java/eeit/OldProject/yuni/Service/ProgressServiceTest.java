package eeit.OldProject.yuni.Service;

import org.junit.jupiter.api.Test;

class ProgressServiceTest {

	@Test
	void testGetProgressByUserAndCourse() {
	
	}

	@Test
	void testGetProgressByUserAndChapter() {
	}

	@Test
	void testCreateProgress() {
	}

	@Test
	void testMarkChapterProgress() {
	}

	@Test
	void testUpdateLastWatchedOnly() {
	}

	@Test
	void testCompleteChapter() {
	}

	@Test
	void testCountCompletedChapters() {
	}

	@Test
	void testCountTotalChapters() {
	}

	@Test
	void testIsCourseCompleted() {
	}

}
